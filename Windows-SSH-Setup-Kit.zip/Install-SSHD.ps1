#Install-SSHD.ps1 - Portable SSH Server Setup for Windows
#Usage: PowerShell -ExecutionPolicy Bypass -File Install-SSHD.ps1 [options]
#Options: -DryRun -Uninstall -GenerateKey -PublicKey -PublicKeyPath -DisablePasswordAuth -SkipGit -SkipTailscale -TailscaleAuthKey -AllowOutboundSSH -NoFullAdmin -SkipFirewall -Force -PauseOnExit

[CmdletBinding()]
param(
    [switch] $DryRun,
    [switch] $Uninstall,
    [switch] $GenerateKey,
    [string] $PublicKey,
    [string] $PublicKeyPath,
    [switch] $DisablePasswordAuth,
    [switch] $SkipGit,
    [switch] $SkipTailscale,
    [string] $TailscaleAuthKey,
    [switch] $AllowOutboundSSH,
    [switch] $NoFullAdmin,
    [switch] $SkipFirewall,
    [switch] $Force,
    [switch] $PauseOnExit
)

function Write-Host-Ln { param([string]$Line); Write-Host $Line }

function Get-LanCidr {
    # Auto-detect LAN CIDR via default route
    $route = Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Where-Object { $_.NextHop -ne '0.0.0.0' } | Sort-Object -Property Metric | Select-Object -First 1
    if ($route) {
        $ip = $route.NextHop
        $parts = $ip -split '\.'
        if ($parts.Count -ge 3) {
            $cidr = "$($parts[0]).$($parts[1]).$($parts[2]).0/24"
            return $cidr
        }
    }
    return '10.0.0.0/24' # fallback
}

function Get-TailscaleSubnets {
    $subnets = @()
    try {
        $ts = & tailscale.exe status -json 2>$null | ConvertFrom-Json 2>$null
        if ($ts) { $subnets = $ts.Attrs.Networks }
    } catch { }
    return $subnets
}

function Install-OpenSSH {
    Write-Host-Ln "==> Installing OpenSSH..."
    if ($DryRun) { Write-Host-Ln "[DRYRUN] Would install OpenSSH via MSI or winget"; return }
    
    $sshdExe1 = 'C:\Windows\System32\OpenSSH\sshd.exe'
    $sshdExe2 = 'C:\Program Files\OpenSSH\sshd.exe'
    if (Test-Path $sshdExe1 -or Test-Path $sshdExe2) {
        Write-Host-Ln "OpenSSH already installed (sshd.exe found)"
        return
    }
    
    # Try MSI first (pinned)
    $msiUrl = 'https://github.com/PowerShell/Win32-OpenSSH/releases/download/10.0.0.0p2-Preview/OpenSSH-Win64-v10.0.0.0.msi'
    $msiSha256 = 'ddec9c53864280759cf9f74791cefd387100e3946aa849a1c138a4ed1b96b7d9'
    $msiPath = "$env:TEMP\OpenSSH-Win64.msi"
    
    Write-Host-Ln "Downloading OpenSSH MSI from pinned URL..."
    if (-not $DryRun) {
        try {
            $wc = New-Object Net.WebClient
            $wc.DownloadFile($msiUrl, $msiPath)
            $sha = (Get-FileHash -Path $msiPath -Algorithm SHA256).Hash
            if ($sha -ne $msiSha256) {
                throw "SHA256 mismatch: expected $msiSha256, got $sha"
            }
            Write-Host-Ln "MSI downloaded and verified"
        } catch {
            Write-Host-Ln "ERROR: Failed to download/verify MSI: $($_.Exception.Message)"
            $winget = (Get-Command winget.exe -ErrorAction SilentlyContinue).Source
            if ($winget) {
                Write-Host-Ln "Trying winget fallback..."
                & $winget install Microsoft.OpenSSH.Preview -scope Machine -silent --acceptPackageAgreements --acceptSourceAgreements 2>&1 | Out-Null
            } else {
                throw "No OpenSSH installed and no winget available"
            }
        }
    } else {
        Write-Host-Ln "[DRYRUN] Would download MSI from $msiUrl"
    }
}

function Install-Git {
    Write-Host-Ln "==> Installing Git for Windows..."
    if ($DryRun) { Write-Host-Ln "[DRYRUN] Would install Git for Windows"; return }
    
    $bash = 'C:\Program Files\Git\bin\bash.exe'
    if (Test-Path $bash) {
        Write-Host-Ln "Git already installed at $bash"
        return
    }
    
    if (-not $SkipGit) {
        Write-Host-Ln "Installing Git via winget..."
        $winget = (Get-Command winget.exe -ErrorAction SilentlyContinue).Source
        if ($winget) {
            & $winget install Git.Git -exact -scope Machine -silent --acceptPackageAgreements --acceptSourceAgreements 2>&1 | Out-Null
        }
    }
    
    if (Test-Path $bash) {
        Write-Host-Ln "Git installed successfully at $bash"
    } else {
        Write-Host-Ln "WARNING: Git bash not found after install, falling back to PowerShell"
    }
}

function Set-DefaultShell {
    Write-Host-Ln "==> Setting DefaultShell to Git Bash..."
    if ($DryRun) { Write-Host-Ln "[DRYRUN] Would set DefaultShell"; return }
    
    $bash = 'C:\Program Files\Git\bin\bash.exe'
    if (Test-Path $bash) {
        New-Item -Path 'HKLM:\SOFTWARE\OpenSSH' -Force | Out-Null
        New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value $bash -PropertyType String -Force | Out-Null
        Write-Host-Ln "DefaultShell = $((Get-ItemProperty 'HKLM:\SOFTWARE\OpenSSH').DefaultShell)"
    } else {
        $psExe = '$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe'
        New-Item -Path 'HKLM:\SOFTWARE\OpenSSH' -Force | Out-Null
        New-ItemProperty -Path 'HKLM:\SOFTWARE\OpenSSH' -Name DefaultShell -Value $psExe -PropertyType String -Force | Out-Null
        Write-Host-Ln "DefaultShell (fallback to PowerShell) = $((Get-ItemProperty 'HKLM:\SOFTWARE\OpenSSH').DefaultShell)"
    }
}

function Configure-SshdConfig {
    $configPath = 'C:\ProgramData\ssh\sshd_config'
    
    Write-Host-Ln "==> Configuring sshd_config..."
    
    if ($DryRun) {
        Write-Host-Ln "[DRYRUN] Would configure $configPath"
        return
    }
    
    # Read current config
    $config = Get-Content -Path $configPath -Raw
    
    # Find the position of "Match Group administrators"
    $matchPos = $config.IndexOf("Match Group administrators")
    
    if ($matchPos -ge 0) {
        # Content before the Match block
        $beforeMatch = $config.Substring(0, $matchPos)
        $afterMatch = $config.Substring($matchPos)
        
        # Ensure global settings
        # Uncomment/comment PasswordAuthentication based on DisablePasswordAuth flag
        if ($DisablePasswordAuth) {
            $newBefore = $beforeMatch -replace '^\s*#\s*PasswordAuthentication\s+yes\s*$', 'PasswordAuthentication no'
            $newBefore = $newBefore -replace '^\s*PasswordAuthentication\s+yes\s*$', 'PasswordAuthentication no'
        } else {
            $newBefore = $beforeMatch -replace '^\s*#\s*PasswordAuthentication\s+no\s*$', 'PasswordAuthentication yes'
            $newBefore = $newBefore -replace '^\s*PasswordAuthentication\s+no\s*$', 'PasswordAuthentication yes'
        }
        
        # Ensure PubkeyAuthentication yes globally
        $newBefore = $newBefore -replace '^\s*#\s*PubkeyAuthentication\s+yes\s*$', 'PubkeyAuthentication yes'
        $newBefore = $newBefore -replace '^\s*#\s*PubkeyAuthentication\s+no\s*$', 'PubkeyAuthentication yes'
        
        # Ensure PermitRootLogin prohibit-password
        $newBefore = $newBefore -replace '^\s*#\s*PermitRootLogin\s+prohibit-password\s*$', 'PermitRootLogin prohibit-password'
        $newBefore = $newBefore -replace '^\s*#\s*PermitRootLogin\s+no\s*$', 'PermitRootLogin prohibit-password'
        
        # Check/fix AuthorizedKeysFile in the Match block
        # The match block should use __PROGRAMDATA__/ssh/administrators_authorized_keys
        $newAfter = $afterMatch
        if ($newAfter -notmatch '__PROGRAMDATA__') {
            $newAfter = $newAfter -replace 'AuthorizedKeysFile\s+\.ssh/authorized_keys', 'AuthorizedKeysFile __PROGRAMDATA__/ssh/administrators_authorized_keys'
        }
        
        # Also ensure the Match block has the right settings inside it
        # PasswordAuthentication yes inside the match block should be overridden
        # but we want the global setting to apply; the match block's AuthorizedKeysFile is the key
        
        $finalConfig = "$newBefore`n$newAfter"
        
        # Write the new config
        Set-Content -Path $configPath -Value $finalConfig -Encoding UTF8 -Force
        Write-Host-Ln "sshd_config updated"
    } else {
        # Real config handling - same logic for actual run
        $config = Get-Content -Path $configPath -Raw
        $matchPos = $config.IndexOf("Match Group administrators")
        
        if ($matchPos -ge 0) {
            $beforeMatch = $config.Substring(0, $matchPos)
            $afterMatch = $config.Substring($matchPos)
            
            if ($DisablePasswordAuth) {
                $newBefore = $beforeMatch -replace '^\s*#\s*PasswordAuthentication\s+yes\s*$', 'PasswordAuthentication no'
                $newBefore = $newBefore -replace '^\s*PasswordAuthentication\s+yes\s*$', 'PasswordAuthentication no'
            } else {
                $newBefore = $beforeMatch -replace '^\s*#\s*PasswordAuthentication\s+no\s*$', 'PasswordAuthentication yes'
                $newBefore = $newBefore -replace '^\s*PasswordAuthentication\s+no\s*$', 'PasswordAuthentication yes'
            }
            
            $newBefore = $newBefore -replace '^\s*#\s*PubkeyAuthentication\s+yes\s*$', 'PubkeyAuthentication yes'
            $newBefore = $newBefore -replace '^\s*#\s*PubkeyAuthentication\s+no\s*$', 'PubkeyAuthentication yes'
            
            $newBefore = $newBefore -replace '^\s*#\s*PermitRootLogin\s+prohibit-password\s*$', 'PermitRootLogin prohibit-password'
            $newBefore = $newBefore -replace '^\s*#\s*PermitRootLogin\s+no\s*$', 'PermitRootLogin prohibit-password'
            
            $newAfter = $afterMatch
            if ($newAfter -notmatch '__PROGRAMDATA__') {
                $newAfter = $newAfter -replace 'AuthorizedKeysFile\s+\.ssh/authorized_keys', 'AuthorizedKeysFile __PROGRAMDATA__/ssh/administrators_authorized_keys'
            }
            
            $finalConfig = "$newBefore`n$newAfter"
            Set-Content -Path $configPath -Value $finalConfig -Encoding UTF8 -Force
            Write-Host-Ln "sshd_config updated"
        }
    }
}

function Configure-Firewall {
    Write-Host-Ln "==> Configuring Firewall rules..."
    
    if ($DryRun) {
        Write-Host-Ln "[DRYRUN] Would configure firewall rules"
        return
    }
    
    # Auto-detect LAN CIDR
    $lanCidr = Get-LanCidr
    Write-Host-Ln "Detected LAN CIDR: $lanCidr"
    
    # Tailscale subnets
    $tailscaleSubnets = Get-TailscaleSubnets
    $tailscaleCidr = '100.64.0.0/10'
    $tailscaleIpv6 = 'fd7a:115c:a1e0::/48'
    
    # Rules to disable (over-broad vendor rules)
    $rulesToDisable = @(
        'OpenSSH SSH Server (sshd)'
        'OpenSSH SSH Server Preview (sshd)'
    )
    
    # Disable over-broad vendor rules
    foreach ($name in $rulesToDisable) {
        $rule = Get-NetFirewallRule -DisplayName $name -ErrorAction SilentlyContinue
        if ($rule) {
            Write-Host-Ln "Disabling over-broad rule: $name"
            if (-not $DryRun) { $rule | Disable-NetFirewallRule }
        }
    }
    
    # Create inbound rule for LAN-scoped SSH
    $lanRuleName = "OpenSSH Server (Local subnet $lanCidr)"
    $lanRule = Get-NetFirewallRule -DisplayName $lanRuleName -ErrorAction SilentlyContinue
    if (-not $lanRule) {
        Write-Host-Ln "Creating inbound SSH rule for LAN: $lanCidr"
        if (-not $DryRun) {
            New-NetFirewallRule -DisplayName $lanRuleName -Direction Inbound -Protocol TCP -LocalPort 22 `
                -RemoteAddress $lanCidr -Action Allow -Enabled True -Profile Private | Out-Null
        }
    } else {
        Write-Host-Ln "LAN SSH rule already exists: $lanRuleName"
        if (-not $DryRun) {
            Set-NetFirewallRule -DisplayName $lanRuleName -RemoteAddress $lanCidr -Enabled True
        }
    }
    
    # Create inbound rule for Tailscale
    $tailscaleRuleName = 'OpenSSH over Tailscale (100.64.0.0/10)'
    $tailscaleRule = Get-NetFirewallRule -DisplayName $tailscaleRuleName -ErrorAction SilentlyContinue
    if (-not $tailscaleRule) {
        Write-Host-Ln "Creating inbound SSH rule for Tailscale"
        if (-not $DryRun) {
            New-NetFirewallRule -DisplayName $tailscaleRuleName -Direction Inbound -Protocol TCP -LocalPort 22 `
                -RemoteAddress 100.64.0.0/10,fd7a:115c:a1e0::/48 -Action Allow -Enabled True -Profile Any | Out-Null
        }
    } else {
        Write-Host-Ln "Tailscale SSH rule already exists: $tailscaleRuleName"
        if (-not $DryRun) {
            Set-NetFirewallRule -DisplayName $tailscaleRuleName -RemoteAddress 100.64.0.0/10,fd7a:115c:a1e0::/48 -Enabled True
        }
    }
    
    # Optionally block outbound SSH to tailnet
    if (-not $AllowOutboundSSH) {
        $blockRuleName = 'Block outbound SSH to tailnet'
        $blockRule = Get-NetFirewallRule -DisplayName $blockRuleName -ErrorAction SilentlyContinue
        if (-not $blockRule) {
            Write-Host-Ln "Creating outbound block rule for SSH to tailnet"
            if (-not $DryRun) {
                New-NetFirewallRule -DisplayName $blockRuleName -Direction Outbound -Protocol TCP -RemotePort 22 `
                    -RemoteAddress 100.64.0.0/10 -Action Block -Enabled True -Profile Any | Out-Null
            }
        } else {
            Write-Host-Ln "Outbound SSH block rule already exists"
        }
    } else {
        Write-Host-Ln "Outbound SSH allowed (per -AllowOutboundSSH)"
    }
    
    Write-Host-Ln "Firewall configuration complete"
}

function Configure-Self-Heal {
    Write-Host-Ln "==> Configuring self-heal (ensure-sshd.ps1 + scheduled task)..."
    
    if ($DryRun) {
        Write-Host-Ln "[DRYRUN] Would configure self-heal components"
        return
    }
    
    $ensurePath = 'C:\ProgramData\ssh\ensure-sshd.ps1'
    $ensureExe = 'C:\Windows\System32\OpenSSH\sshd.exe'
    if (-not (Test-Path $ensureExe)) { $ensureExe = 'C:\Program Files\OpenSSH\sshd.exe' }
    
    # Write ensure-sshd.ps1
    $ensureContent = @"
# Creates/repairs the sshd service and starts it. Safe to run repeatedly.
$ErrorActionPreference = 'SilentlyContinue'
$exe = '$ensureExe'
if (-not (Test-Path $exe)) { exit 1 }
if (-not (Get-Service sshd -ErrorAction SilentlyContinue)) {
    New-Service -Name sshd -BinaryPathName $exe -DisplayName 'OpenSSH SSH Server' `
        -StartupType Automatic -Description 'OpenSSH SSH Server' | Out-Null
    Start-Sleep -Seconds 2
}
Set-Service -Name sshd -StartupType Automatic
if ((Get-Service sshd).Status -ne 'Running') {
    Start-Service -Name sshd
    Start-Sleep -Seconds 1
}
# heartbeat (kept small: last 200 lines)
$line = "{0}  action={1}  status={2}" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), 'started', (Get-Service sshd).Status
Add-Content -Path 'C:\ProgramData\ssh\ensure-sshd.log' -Value $line
$c = @(Get-Content 'C:\ProgramData\ssh\ensure-sshd.log' -ErrorAction SilentlyContinue)
if ($c.Count -gt 200) { $c | Select-Object -Last 200 | Set-Content 'C:\ProgramData\ssh\ensure-sshd.log' }
"@
    
    Set-Content -Path $ensurePath -Value $ensureContent -Encoding ASCII -Force
    Write-Host-Ln "Wrote $ensurePath"
    
    # Register scheduled task: At startup AND every 5 minutes
    Write-Host-Ln "Registering scheduled task 'OpenSSH sshd ensure-start'..."
    $act = New-ScheduledTaskAction -Execute 'powershell.exe' `
        -Argument '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "C:\ProgramData\ssh\ensure-sshd.ps1"'
    
    $trgBoot = New-ScheduledTaskTrigger -AtStartup
    
    # Repetition block for every 5 minutes
    $trgRepeat = New-ScheduledTaskTrigger -Once -At (Get-Date) `
        -RepetitionInterval (New-TimeSpan -Minutes 5) `
        -RepetitionDuration (New-TimeSpan -Days 3650)
    $trgBoot.Repetition = $trgRepeat.Repetition
    
    $prn = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
    $set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries `
        -ExecutionTimeLimit (New-TimeSpan -Minutes 5) -StartWhenAvailable -MultipleInstances IgnoreNew
    
    Register-ScheduledTask -TaskName 'OpenSSH sshd ensure-start' `
        -Action $act -Trigger @($trgBoot) -Principal $prn -Settings $set -Force | Out-Null
    Write-Host-Ln "Task registered: OpenSSH sshd ensure-start"
    
    # Also ensure the task runs after a reboot if RebootPending
    $rebootPending = Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending'
    if ($rebootPending) {
        Write-Host-Ln "Reboot pending detected - self-heal task will ensure sshd starts after reboot"
    }
}

function Generate-SshKeys {
    Write-Host-Ln "==> Generating SSH keys..."
    
    if ($DryRun) {
        Write-Host-Ln "[DRYRUN] Would generate SSH keys"
        return
    }
    
    $sshDir = 'C:\ProgramData\ssh'
    $keyPath = Join-Path $sshDir 'ssh_host_rsa_key'
    
    if (Test-Path $keyPath) {
        Write-Host-Ln "SSH host key already exists"
    } else {
        Write-Host-Ln "Generating new SSH host key..."
        if (-not $DryRun) {
            & 'C:\Program Files\OpenSSH\ssh-keygen.exe' -A 2>$null
        }
        Write-Host-Ln "Host keys generated"
    }
}

function Setup-AuthorizedKeys {
    Write-Host-Ln "==> Setting up authorized keys for Admin..."
    
    if ($DryRun) {
        Write-Host-Ln "[DRYRUN] Would set up authorized keys"
        return
    }
    
    $adminKeyPath = 'C:\Users\Admin\.ssh\authorized_keys'
    $programKeyPath = 'C:\ProgramData\ssh\administrators_authorized_keys'
    
    # Ensure .ssh directory exists
    $adminSshDir = 'C:\Users\Admin\.ssh'
    if (-not (Test-Path $adminSshDir)) {
        New-Item -Path $adminSshDir -ItemType Directory -Force | Out-Null
    }
    
    # If -TailscaleAuthKey provided, use that key
    if ($TailscaleAuthKey) {
        Write-Host-Ln "Using Tailscale auth key: $TailscaleAuthKey"
        if (Test-Path $TailscaleAuthKey) {
            Copy-Item -Path $TailscaleAuthKey -Destination $programKeyPath -Force
        } else {
            Set-Content -Path $programKeyPath -Value $TailscaleAuthKey -Encoding UTF8
        }
        Write-Host-Ln "Auth key written to $programKeyPath"
    } else {
        # Check if key already exists
        if (Test-Path $programKeyPath) {
            $existing = Get-Content -Path $programKeyPath -Encoding UTF8 -ErrorAction SilentlyContinue
            if ($existing) {
                Write-Host-Ln "Existing authorized keys found at $programKeyPath"
            }
        } else {
            Write-Host-Ln "No existing authorized keys - creating empty target (admin must add their key)"
            Set-Content -Path $programKeyPath -Value '' -Encoding UTF8
        }
    }
    
    # User-level authorized_keys note
    Write-Host-Ln "User-level ~/.ssh/authorized_keys will be used for regular users"
    Write-Host-Ln "Admin-level __PROGRAMDATA__/ssh/administrators_authorized_keys is the target for full admin access"
}

function Main {
    Write-Host-Ln "=========================================="
    Write-Host-Ln "  Install-SSHD.ps1 - SSH Server Setup"
    Write-Host-Ln "=========================================="
    Write-Host-Ln ""
    
    # Handle Uninstall first
    if ($Uninstall) {
        Write-Host-Ln "=== Uninstall mode ==="
        # Remove scheduled task
        Unregister-ScheduledTask -TaskName 'OpenSSH sshd ensure-start' -Force -ErrorAction SilentlyContinue
        # Remove ensure-sshd.ps1
        Remove-Item -Path 'C:\ProgramData\ssh\ensure-sshd.ps1' -Force -ErrorAction SilentlyContinue
        # Remove sshd service
        Uninstall-Service sshd -ErrorAction SilentlyContinue
        # Remove firewall rules (this is simplified)
        Write-Host-Ln "Uninstall complete (basic cleanup)"
        if ($PauseOnExit -and -not $DryRun) { Read-Host "Press Enter to exit" }
        return
    }
    
    # Install OpenSSH
    Install-OpenSSH
    
    # Install Git
    Install-Git
    
    # Set DefaultShell
    Set-DefaultShell
    
    # Configure sshd_config
    Configure-SshdConfig
    
    # Configure Firewall
    Configure-Firewall
    
    # Configure self-heal
    Configure-Self-Heal
    
    # Generate keys if requested
    if ($GenerateKey -or $PublicKey) {
        Generate-SshKeys
    }
    
    # Set up authorized keys
    Setup-AuthorizedKeys
    
    # Restart sshd to pick up changes
    Write-Host-Ln "Restarting sshd service..."
    if (-not $DryRun) {
        Restart-Service sshd -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
    }
    Write-Host-Ln "sshd service restarted"
    
    Write-Host-Ln ""
    Write-Host-Ln "=========================================="
    Write-Host-Ln "  Setup complete!"
    Write-Host-Ln "=========================================="
    
    if ($PauseOnExit -and -not $DryRun) {
        Read-Host "Press Enter to exit"
    }
}

# Run main function
Main